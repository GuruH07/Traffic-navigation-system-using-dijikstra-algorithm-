import java.util.*;

class Graph {
    private final Map<String, List<Edge>> adjList;

    public Graph() {
        adjList = new HashMap<>();
    }

    // Add a node to the graph
    public void addNode(String node) {
        adjList.putIfAbsent(node, new ArrayList<>());
    }

    // Add an edge between two nodes with weight (distance or time)
    public void addEdge(String from, String to, int weight) {
        adjList.get(from).add(new Edge(to, weight));
        adjList.get(to).add(new Edge(from, weight));  // Assuming undirected graph
    }

    // Get all nodes in the graph
    public Set<String> getNodes() {
        return adjList.keySet();
    }

    // Get the edges of a particular node
    public List<Edge> getEdges(String node) {
        return adjList.get(node);
    }

    // Edge class representing a road with destination and weight
    static class Edge {
        String destination;
        int weight;

        public Edge(String destination, int weight) {
            this.destination = destination;
            this.weight = weight;
        }
    }
}

class Dijkstra {
    private final Graph graph;

    public Dijkstra(Graph graph) {
        this.graph = graph;
    }

    // Function to perform Dijkstra's algorithm from a source node
    public Map<String, Integer> findShortestPaths(String source) {
        PriorityQueue<Node> pq = new PriorityQueue<>(Comparator.comparingInt(node -> node.distance));
        Map<String, Integer> distances = new HashMap<>();
        Map<String, String> previousNodes = new HashMap<>();

        // Initialize distances and add source node to priority queue
        for (String node : graph.getNodes()) {
            distances.put(node, Integer.MAX_VALUE);  // Initially set all distances to infinity
        }
        distances.put(source, 0);
        pq.add(new Node(source, 0));

        while (!pq.isEmpty()) {
            Node currentNode = pq.poll();
            String currentNodeName = currentNode.name;

            // Explore each adjacent node
            for (Graph.Edge edge : graph.getEdges(currentNodeName)) {
                String neighbor = edge.destination;
                int newDist = distances.get(currentNodeName) + edge.weight;

                // If a shorter path to the neighbor is found, update the distance
                if (newDist < distances.get(neighbor)) {
                    distances.put(neighbor, newDist);
                    previousNodes.put(neighbor, currentNodeName);
                    pq.add(new Node(neighbor, newDist));
                }
            }
        }

        return distances;
    }

    // Function to reconstruct the shortest path from source to destination
    public List<String> getShortestPath(String source, String destination) {
        Map<String, String> previousNodes = new HashMap<>();
        findShortestPaths(source); // Run Dijkstra to populate distances and previousNodes

        List<String> path = new ArrayList<>();
        for (String at = destination; at != null; at = previousNodes.get(at)) {
            path.add(at);
        }
        Collections.reverse(path); // Reverse the path to get it from source to destination
        return path;
    }

    // Node class to store a node and its distance from the source
    static class Node {
        String name;
        int distance;

        public Node(String name, int distance) {
            this.name = name;
            this.distance = distance;
        }
    }
}

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Create the graph (road network)
        Graph graph = new Graph();

        // Input nodes (intersections)
        System.out.println("Enter the number of nodes:");
        int numNodes = scanner.nextInt();
        scanner.nextLine();  // Consume newline
        for (int i = 0; i < numNodes; i++) {
            System.out.println("Enter node name:");
            String nodeName = scanner.nextLine();
            graph.addNode(nodeName);
        }

        // Input edges (roads)
        System.out.println("Enter the number of edges:");
        int numEdges = scanner.nextInt();
        scanner.nextLine();  // Consume newline
        for (int i = 0; i < numEdges; i++) {
            System.out.println("Enter edge details (from, to, weight):");
            String from = scanner.nextLine();
            String to = scanner.nextLine();
            int weight = scanner.nextInt();
            scanner.nextLine();  // Consume newline
            graph.addEdge(from, to, weight);
        }

        // Create Dijkstra object to find shortest paths
        Dijkstra dijkstra = new Dijkstra(graph);

        // Query for shortest paths
        System.out.println("Enter the source node for shortest path calculation:");
        String sourceNode = scanner.nextLine();

        System.out.println("Enter the destination node for shortest path calculation:");
        String destinationNode = scanner.nextLine();

        // Get shortest paths from the source node
        Map<String, Integer> distances = dijkstra.findShortestPaths(sourceNode);
        System.out.println("Shortest distances from " + sourceNode + ": " + distances);

        // Get the shortest path from source to destination
        List<String> path = dijkstra.getShortestPath(sourceNode, destinationNode);
        System.out.println("Shortest path from " + sourceNode + " to " + destinationNode + ": " + path);
        System.out.println("Total distance: " + distances.get(destinationNode));
    }
}

